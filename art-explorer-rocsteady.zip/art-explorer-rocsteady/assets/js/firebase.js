
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyB3eOhFfdrQc6uNTJ6CEwM6XExTVdOoFls",
    authDomain: "locart-1517073423936.firebaseapp.com",
    databaseURL: "https://locart-1517073423936.firebaseio.com",
    projectId: "locart-1517073423936",
    storageBucket: "locart-1517073423936.appspot.com",
    messagingSenderId: "447594602678"
  };
  firebase.initializeApp(config);
